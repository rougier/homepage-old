#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
'''Arbitrary inline element positioned within a formatted document.

  An element  is a graphic  component that can  be embedded within  a formatted
  document to  render any  kind of  graphics. It is  the responsibility  of the
  element to  clip itself against its viewport  that is guaranteed to  be up to
  date.  The easiest  way to  ensure the  clipping is  to use  the  scissor box
  provided by OpenGL.

  Example:
  --------

  def draw(self):
      glViewport(x,y,w,h)
      glScissor(x,y,w,h)
      glEnable(GL_SCISSOR_TEST)
      
      ...

      glDisable(GL_SCISSOR_TEST)

  If the element wants to interact  either with keyboard or mouse, it is better
  to test first  if the element got the mouse  focus. A ``hit_test``function is
  provided for this purpose:

  Example:
  --------

  def on_mouse_press(self, x, y, button, modifiers):
      if self.hit_test(x,y):
          ...
          return pyglet.event.EVENT_HANDLED
      return pyglet.event.EVENT_UNHANDLED
'''
import ctypes
import pyglet
from pyglet.gl import *
from pyglet.event import EventDispatcher
from pyglet.text.document import InlineElement


# ------------------------------------------------------------------------------
class Element(InlineElement, EventDispatcher):
    '''Arbitrary inline element positioned within a formatted document.

    Elements behave like a single glyph  in the document.  They are measured by
    their width and their height.
    
    The pyglet layout classes reserve space in the layout for elements and call
    the  element's methods  to  ensure  they are  rendered  at the  appropriate
    position.

    If the  size of  a element  (any of the  `advance`, `ascent`,  or `descent`
    instance variables)  is modified it is the  application's responsibility to
    trigger a reflow of the appropriate area in the affected layouts.  This can
    be done by forcing a style change over the element's position.

    '''

    # _________________________________________________________________ __init__
    def __init__(self, width=600, height=400):
        ''' '''
        super(Element,self).__init__(height, 0, width)
        self._width = width
        self._height = height
        self._x = 0
        self._y = 0
        self._layout = None

    # ____________________________________________________________________ place
    def place(self, layout, x, y):
        '''Construct an instance of the element at the given coordinates.

        Called when the element's position within a layout changes, either
        due to the initial condition, changes in the document or changes in
        the layout size.

        It is the responsibility of the element to clip itself against
        the layout boundaries, and position itself appropriately with respect
        to the layout's position and viewport offset.  
        
        The `TextLayout.top_state` graphics state implements this transform
        and clipping into window space.

        :Parameters:
            `layout` : `pyglet.text.layout.TextLayout`
                The layout the element moved within.
            `x` : int
                Position of the left edge of the element, relative
                to the left edge of the document, in pixels.
            `y` : int
                Position of the baseline, relative to the top edge of the
                document, in pixels.  Note that this is typically negative.
        '''
        self._layout, self._x, self._y = layout, x, y

    # ___________________________________________________________________ remove
    def remove(self, layout):
        '''Remove this element from a layout.

        The couterpart of `place`; called when the element is no longer
        visible in the given layout.

        :Parameters:
            `layout` : `pyglet.text.layout.TextLayout`
                The layout the element was removed from.

        '''
        self._layout = None

    # ________________________________________________________________ viewport
    def _get_viewport(self):
        return (self.x,self.y,self.width,self.height)
    viewport = property(_get_viewport,
                 doc="Up to date element viewport.")

    # _______________________________________________________________________ x
    def _get_x(self):
        if self._layout:
            return self._x + self._layout.top_group.left - self._layout.view_x
        else:
            return self._x
    x = property(_get_x,
                 doc="X absolute coordinate of the element.")

    # _______________________________________________________________________ y
    def _get_y(self):
        if self._layout:
            return self._y + self._layout.top_group.top - self._layout.view_y
        else:
            return self._y
    y = property(_get_y,
                 doc="Y absolute coordinate of the element.")

    # ___________________________________________________________________ width
    def _get_width(self):
        return self._width
    width = property(_get_width,
                     doc="Width of the element.")

    # __________________________________________________________________ height
    def _get_height(self):
        return self._height
    height = property(_get_height,
                      doc="Height of the element.")

    # __________________________________________________________________ height
    def _get_layout(self):
        return self._layout
    layout = property(_get_layout,
                      doc="Layout where element is currently inserted.")

    # _________________________________________________________________ hit_test
    def hit_test(self, x, y):
        ''' Tells whether (x,y) is within the element or not.'''
        return (self.x <= x <= (self.x+self.width) and
                   self.y <= y <= (self.y+self.height))

    # ____________________________________________________________________ draw
    def draw(self, viewport=None):
        ''' Draw the element '''
        raise NotImplementedError('abstract')

    # ____________________________________________________________________ save
    def save (self, filename, size = 1024):
        ''' Save viewport to a bitmap file '''

        viewport = (GLint*4)()
        glGetIntegerv(GL_VIEWPORT, viewport)
        x,y,w,h = viewport
        shape = (self.width,self.height)
        W = int(round(shape[0]/float(max(shape[0],shape[1])) * size))
        H = int(round(shape[1]/float(max(shape[0],shape[1])) * size))

        # Setup framebuffer
        framebuffer = GLuint()
        glGenFramebuffersEXT(1, framebuffer)
        if not framebuffer.value:
            raise RuntimeError('Cannot create framebuffer')
        glBindFramebufferEXT(GL_FRAMEBUFFER_EXT, framebuffer)

        # Setup depthbuffer
        depthbuffer = GLuint()
        glGenRenderbuffersEXT(1, depthbuffer)
        glBindRenderbufferEXT (GL_RENDERBUFFER_EXT, depthbuffer)
        glRenderbufferStorageEXT (GL_RENDERBUFFER_EXT, GL_DEPTH_COMPONENT, W, H)

        # Create texture to render to
        texture = GLuint()
        glGenTextures(1, byref(texture))
        glBindTexture (GL_TEXTURE_2D, texture)
        glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR)
        glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR)
        glTexImage2D (GL_TEXTURE_2D, 0, GL_RGBA, W, H, 0,
                      GL_RGBA, GL_UNSIGNED_BYTE, 0)
        glFramebufferTexture2DEXT (GL_FRAMEBUFFER_EXT,
                                   GL_COLOR_ATTACHMENT0_EXT,
                                   GL_TEXTURE_2D, texture, 0);
        glFramebufferRenderbufferEXT(GL_FRAMEBUFFER_EXT,
                                     GL_DEPTH_ATTACHMENT_EXT, 
                                     GL_RENDERBUFFER_EXT, depthbuffer);
        status = glCheckFramebufferStatusEXT (GL_FRAMEBUFFER_EXT);
        if status != GL_FRAMEBUFFER_COMPLETE_EXT:
            raise RuntimeError('Error in framebuffer activation')

        # Resize, render & save
        data = (GLubyte * (W*H*4))()
        glViewport(0,0,W,H)
        glMatrixMode(gl.GL_PROJECTION)
        glPushMatrix()
        glLoadIdentity()
        glOrtho(0, W, 0, H, -1, 1)
        glClearColor(1,1,1,0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
        self.draw((0,0,W,H))
        glPopMatrix()
        glMatrixMode(gl.GL_MODELVIEW)
        glReadPixels(0, 0, W, H, GL_RGBA,  GL_UNSIGNED_BYTE, byref(data))
        image = pyglet.image.ImageData(W, H, 'RGBA', data)
        image.save(filename)

        # Cleanup
        glBindRenderbufferEXT (GL_RENDERBUFFER_EXT, 0)
        glBindFramebufferEXT (GL_FRAMEBUFFER_EXT, 0)
        glDeleteTextures (1, texture)
        glDeleteFramebuffersEXT(1,framebuffer)

        # Restoring previous viewport
        glViewport(x,y,w,h)
