#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
''' '''
import numpy
import pyglet
from pyglet.gl import *
from pyglet.window import key
from texture import Texture
from glipy.elements.element import Element
from colormap import IceAndFire, Ice, Fire, Hot, Grey

# ------------------------------------------------------------------------------
class Figure(Element):

    # _________________________________________________________________ __init__
    def __init__ (self, items, zoom=1.0, pad=1, cmap=None,
                  height=400, window=None, *args, **kwargs):
        ''' '''

        self._pad     = pad
        self._cmap    = cmap
        self._items   = items
        self._objects = []
        self._shape   = (1,1)
        self.set_items(items)
        width = int(height*(self._shape[0]/float(self._shape[1])))
        self._size     = [width,height]
        self._shift    = [0,0]
        self._zoom     = 1
        self._focus    = False
        self._drag     = False
        self._window   = window
        super(Figure,self).__init__(width=width, height=height)


    # ________________________________________________________________ set_items
    def set_items(self, items):
        ''' '''

        self._items = items
        shape, Z_index = (0,0), []

        # Is items a single array or tuple ?
        if isinstance(items,numpy.ndarray) or isinstance(items,tuple):
            shape = (1,1)
            Z_index.append ([items, (0,0)])
        # Is items a list ?
        elif isinstance(items, list):
            s = [item for item in items if isinstance(item,list)]
            if not s:
                shape = (1,len(items))
                for i in range (len(items)):
                    Z_index.append([items[i],(0,i)])
            else:
                shape = (len(items), max(len(item) for item in s))
                for i in range (len(items)):
                    if isinstance(items[i],list):
                        for j in range(len(items[i])):
                            Z_index.append([items[i][j],(i,j)])
                    else:
                        Z_index.append([items[i],(i,0)])

        # Create a numpy array with items at the right place
        Z = numpy.ndarray(shape=shape,dtype=object)
        Z[...] = None
        for z, index in Z_index:
            if isinstance(z, tuple):
                if isinstance (z[0], numpy.ndarray):
                    Z[index] = (numpy.atleast_2d(z[0]),z[1])
                else:
                    Z[index] = (z[0],z[1])
            else:
                if isinstance (z, numpy.ndarray):
                    Z[index] = (numpy.atleast_2d(z),1)
                else:
                    Z[index] = (z,1)

        # Computes rows and columns size
        # First pass: we do not take into account array that span several rows
        # or columns
        sizes = [[0]*shape[0], [0]*shape[1]]
        for i in range(Z.shape[0]):
            for j in range(Z.shape[1]):
                if Z[i,j] is None:
                    continue
                z,zoom = Z[i,j]
                if isinstance (z, numpy.ndarray):
                    # Lines height
                    if ((i==(Z.shape[0]-1))
                        or (Z[i+1,j] is not None and Z[i+1,j][0] != '|')):
                        if (z.shape[0]*zoom+self._pad) > sizes[0][i]:
                            sizes[0][i] = z.shape[0]*zoom+self._pad
                    # Columns width
                    if ((j==(Z.shape[1]-1))
                        or (Z[i,j+1] is not None and Z[i,j+1][0] != '-')):
                        if (z.shape[1]*zoom+self._pad) > sizes[1][j]:
                            sizes[1][j] = z.shape[1]*zoom+self._pad
        # Computes rows and columns 
        # Second pass: we only take into account array that span several rows
        # or columns
        for i in range(Z.shape[0]):
            for j in range(Z.shape[1]):
                if Z[i,j] is None:
                    continue
                z,zoom = Z[i,j]
                if isinstance (z, numpy.ndarray):
                    # Lines height
                    if (i<(Z.shape[0]-1)) and Z[i+1,j] is not None and Z[i+1,j][0] == '|':
                        n = 1
                        for k in range(i+1,Z.shape[0]):
                            if Z[k,j][0] == '|': n += 1
                            else:                break
                        s = z.shape[0]*zoom
                        for kk in range(i,k):
                            s = s - sizes[0][kk]
                        sizes[0][k] = max(s+self._pad, sizes[0][k])
                    # Columns width
                    if (j<(Z.shape[1]-1)) and Z[i,j+1] is not None and Z[i,j+1][0] == '-':
                        n = 1
                        for k in range(j+1,Z.shape[1]):
                            if Z[i,k][0] == '-': n += 1
                            else:             break
                        s = z.shape[1]*zoom
                        for kk in range(j,k):
                            s = s - sizes[1][kk]
                        sizes[1][k] = max(s+self._pad, sizes[1][k])
        # Compute final position and size
        s0 = float(sum(sizes[1])-self._pad)
        s1 = float(sum(sizes[0])-self._pad)
        shape = (s0,s1)
        objects = []
        for i in range(Z.shape[0]):
            for j in range(Z.shape[1]):
                if Z[i,j] is None:
                    continue
                z,zoom = Z[i,j]
                if isinstance (z, numpy.ndarray):
                    y = ( sum(sizes[0][0:i],0) )/shape[1]
                    x = ( sum(sizes[1][0:j],0) )/shape[0]
                    h = ( z.shape[0]*zoom )/shape[1]
                    w = ( z.shape[1]*zoom )/shape[0]
                    label = pyglet.text.Label ('', color=(127,127,127,200),
                                               font_size = 24,
                                               anchor_x='left', anchor_y='bottom')
                    objects.append((Texture(z,cmap=self._cmap),label, x,y,w,h))
        self._objects = objects
        self._shape = shape

    # _______________________________________________________________ on_update
    def update(self, dt=0):
        ''' '''
        for obj in self._objects:
            Z,label,zx,zy,zw,zh = obj
            if hasattr(Z.Z,'name'):
                label.text = Z.Z.name
            Z.update()

    # ____________________________________________________________________ draw
    def draw(self ,viewport=None):
        ''' '''      
        self.update()
        if viewport:
            x,y,w,h = viewport
            W = int(w*(self._size[0]/self.width)*self._zoom)
            H = int(h*(self._size[1]/self.height)*self._zoom)
            X = int(w*self._shift[0]/self.width +x+(w-W)/2)
            Y = int(h*self._shift[1]/self.height +y+(h-H)/2)
        else:
            x,y,w,h = self.x, self.y, self.width, self.height
            W = self._size[0]*self._zoom
            H = self._size[1]*self._zoom
            X = self._shift[0]+x+(w-W)/2
            Y = self._shift[1]+y+(h-H)/2
        glPushAttrib(GL_ALL_ATTRIB_BITS)
        if not viewport:
            glScissor(x,y,w,h)
            glEnable(GL_SCISSOR_TEST)
        glColor4f(1,1,1,1)
        glEnable(GL_BLEND)
        for obj in self._objects:
            Z,label,zx,zy,zw,zh = obj
            Z.blit(X+zx*W, Y+zy*H, zw*W, zh*H)
            label.x, label.y = X+zx*W+5, Y+zy*H+5
            label.draw()
        glDisable (GL_TEXTURE_2D)
        glColor4f(.5,.5,.5,1)
        for obj in self._objects:
            Z,label,zx,zy,zw,zh = obj
            zx,zy,zw,zh = X+zx*W, Y+zy*H, zw*W, zh*H
            glBegin(GL_LINE_LOOP)
            glVertex2f(zx   +0.315, zy   +0.315)
            glVertex2f(zx   +0.315, zy+zh-0.315)
            glVertex2f(zx+zw-0.315, zy+zh-0.315)
            glVertex2f(zx+zw-0.315, zy   +0.315)
            glEnd()
        glEnable (GL_TEXTURE_2D)
        glDisable(GL_SCISSOR_TEST)
        glPopAttrib()

    # _________________________________________________________________ on_text
    def on_text (self, text):
        ''' '''
        #if self._focus and text in ['s','S']:
        # Here we prevent the 's' test to be passed to the terminal
        # since we already handled it in the key press handler.
        #return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    # ____________________________________________________________ on_key_press
    def on_key_press (self, symbol, modifiers):
        if not self._focus:
            return pyglet.event.EVENT_UNHANDLED
        elif key.MOD_CTRL & modifiers and symbol == pyglet.window.key.S:
            self.save('screenshot.png')
            return pyglet.event.EVENT_HANDLED
        elif symbol == pyglet.window.key.ESCAPE:
            if self._shift != [0,0]:
                self._shift = [0,0]
            elif self._zoom != 1.0:
                self._zoom = 1.0
            return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    # _________________________________________________________ on_mouse_scroll
    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        ''' '''
        if self.hit_test(x,y):
            if scroll_y > 0:
                self._zoom *= 1.1
            elif scroll_y < 0:
                self._zoom *= 1.0/1.1
            if self._zoom < 0.01:
                self._zoom  = 0.01
            if self._zoom > 100:
                self._zoom = 100
            return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    # __________________________________________________________ on_mouse_press
    def on_mouse_press(self, x, y, button, modifiers):
        ''' '''
        if (self.hit_test(x,y) and button == pyglet.window.mouse.LEFT and
            modifiers & key.MOD_SHIFT):
            self._focus = True
            self._drag = True
            return pyglet.event.EVENT_HANDLED

        elif self.hit_test(x,y) and button == pyglet.window.mouse.LEFT:
            w,h = self.width, self.height
            W = self._size[0]*self._zoom
            H = self._size[1]*self._zoom
            X = self._shift[0]+self.x+(w-W)/2
            Y = self._shift[1]+self.y+(h-H)/2
            for obj in self._objects:
                Z,label,zx,zy,zw,zh = obj
                if (((X+zx*W)< x <(X+(zx+zw)*W) and (Y+zy*H)< y <(Y+(zy+zh)*H))):                
                    i = int((y-(Y+zy*H))/float(zh*H)*Z.shape[0])
                    j = int((x-(X+zx*W))/float(zw*W)*Z.shape[1])
                    if self._window:
                        self._window.dispatch_event('on_select', Z.Z, i, j)
                    return pyglet.event.EVENT_HANDLED
            if self._window:
                self._window.dispatch_event('on_select', None, -1, -1)
            return pyglet.event.EVENT_HANDLED
        self._focus = False
        self._drag = False
        return pyglet.event.EVENT_UNHANDLED

    # ________________________________________________________ on_mouse_release
    def on_mouse_release(self, x, y, button, modifiers):
        ''' '''
        self._drag = False
        if self.hit_test(x,y):
            self._focus = True
            return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    # ___________________________________________________________ on_mouse_drag
    def on_mouse_drag(self, x, y, dx, dy, button, modifiers):
        ''' '''
        if self._drag:
            self._shift[0] += dx
            self._shift[1] += dy
            return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    # _________________________________________________________ on_mouse_motion
    def on_mouse_motion(self, x, y, button, modifiers):
        ''' '''
        if self._drag:
            self._window.set_mouse_cursor(None)
            return pyglet.event.EVENT_HANDLED
        if self.hit_test(x,y):
            self._focus = True
            self._window.set_mouse_cursor(None)
            return pyglet.event.EVENT_HANDLED
        self._focus = False
        return pyglet.event.EVENT_UNHANDLED


pyglet.window.Window.register_event_type('on_select')

