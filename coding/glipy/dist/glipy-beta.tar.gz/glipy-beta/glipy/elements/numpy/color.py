#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
''' RGBA Color object '''

# ------------------------------------------------------------------------------
class Color(object):
    
    # _________________________________________________________________ __init__
    def __init__(self, *args, **kwargs):
        '''

        Color(l)
        Color(l,a)
        Color(r,g,b)
        Color(r,g,b,a)

        Create a color from parameters

        Parameters:
        -----------
        l: float
           normalized luminance value
        r: float
           normalized red value
        g: float
           normalized green value
        b: float
           normalized blue value
        a: float
           normalized alpha value
        '''

        if len(args) > 1:
            color = args
        else:
            color = args[0]
        r = g = b = a = 1.0
        if type(color) == Color:
            r = color.r
            g = color.g
            b = color.b
            a = color.a
        elif type(color) == float or type(color) == int:
            r = g = b = color
            a = 1.0
        elif type(color) == str:
            if color[0] == '#':
                color = color[1:]
                if len(color) == 6:
                    r, g, b = color[:2], color[2:4], color[4:]
                    r, g, b = [int(n, 16) for n in (r, g, b)]
                    r, g, b = r/255.0, g/255.0, b/255.0
                elif len(color) == 8:
                    r, g, b, a = color[:2], color[2:4], color[4:6], color[6:],
                    r, g, b, a = [int(n, 16) for n in (r, g, b, a)]
                    r, g, b, a = r/255.0, g/255.0, b/255.0, a/255.0
                else:
                    raise ValueError, "%s does not correspond to a known color" % color
            else:
                raise ValueError, "%s does not correspond to a known color" % color
        elif type(color) in[tuple, list]:
            if len(color) == 1:
                r = g = b = color[0]
                a = 1.0
            elif len(color) == 2:
                r = g = b = color[0]
                a = color[1]
            elif len(color) >= 3:
                r,g,b = color[0],color[1],color[2]
                a = 1.0
            if len(color) == 4:
                r,g,b = color[0],color[1],color[2]
                a = color[3]
        else:
            raise ValueError, "%s does not correspond to a known  color" % color
        if 'alpha' in kwargs:
            a = kwargs['alpha']
        self.color = [float(r),float(g),float(b),float(a)]

    # ______________________________________________________________________ rgb
    def _get_rgb(self):
        return (self.color[0]*255,
                self.color[1]*255,
                self.color[2]*255)
    def _set_rgb(self, rgb):
        self._set_r(rgb[0])
        self._set_g(rgb[1])
        self._set_b(rgb[2])
    rgb = property(_get_rgb, _set_rgb,
                   doc="3-tuple of normalized RGB channels")

    # ______________________________________________________________________ RGB
    def _get_RGB(self):
        return (int(self.color[0]*255),
                int(self.color[1]*255),
                int(self.color[2]*255))
    def _set_RGB(self, RGB):
        self._set_R(RGB[0])
        self._set_G(RGB[1])
        self._set_B(RGB[2])
    RGB = property(_get_RGB, _set_RGB,
                   doc="3-tuple of RGB channels")

    # _____________________________________________________________________ rgba
    def _get_rgba(self):
        return (self.color[0],
                self.color[1],
                self.color[2],
                self.color[3])
    def _set_rgba(self, rgba):
        self._set_r(rgba[0])
        self._set_g(rgba[1])
        self._set_b(rgba[2])
        self._set_a(rgba[3])        
    rgba = property(_get_rgba, _set_rgba,
                    doc="4-tuple of normalized RGBA channels")

    # _____________________________________________________________________ RGBA
    def _get_RGBA(self):
        return (int(self.color[0]*255),
                int(self.color[1]*255),
                int(self.color[2]*255),
                int(self.color[3]*255))
    def _set_RGBA(self, RGBA):
        self._set_R(RGBA[0])
        self._set_G(RGBA[1])
        self._set_B(RGBA[2])
        self._set_A(RGBA[3])        
    RGBA = property(_get_RGBA, _set_RGBA,
                    doc="4-tuple of RGBA channels")

    # ________________________________________________________________________ r
    def _get_r(self):
        return self.color[0]
    def _set_r(self, r):
        self.color[0] = max(0.0,min(1.0,r))
    r = property(_get_r, _set_r,
                 doc="Normalized red channel")

    # ________________________________________________________________________ g
    def _get_g(self):
        return self.color[1]
    def _set_g(self, g):
        self.color[1] = max(0.0,min(1.0,g))
    g = property(_get_g, _set_g,
                 doc="Normalized green channel")

    # ________________________________________________________________________ b
    def _get_b(self):
        return self.color[2]
    def _set_b(self, b):
        self.color[2] = max(0.0,min(1.0,g))
    b = property(_get_b, _set_b,
                 doc="Normalized blue channel")

    # ________________________________________________________________________ a
    def _get_a(self):
        return self.color[3]
    def _set_a(self, a):
        self.color[3] = max(0.0,min(1.0,a))
    a = property(_get_a, _set_a,
                 doc="Normalized alpha channel")

    # ________________________________________________________________________ R
    def _get_R(self):
        return int(self.color[0]*255)
    def _set_R(self, R):
        self.color[0] = max(0.0,min(1.0,round(R/255.0,2)))
    R = property(_get_R, _set_R,
                 doc="Red channel (0-255)")

    # ________________________________________________________________________ G
    def _get_G(self):
        return int(self.color[1]*255)
    def _set_G(self, G):
        self.color[1] = max(0.0,min(1.0,round(G/255.0,2)))
    G = property(_get_G, _set_G,
                 doc="Green channel (0-255)")

    # ________________________________________________________________________ B
    def _get_B(self):
        return int(self.color[2]*255)
    def _set_B(self, B):
        self.color[2] = max(0.0,min(1.0,round(B/255.0,2)))
    B = property(_get_B, _set_B,
                 doc="Blue channel (0-255)")

    # ________________________________________________________________________ A
    def _get_A(self):
        return int(self.color[3]*255)
    def _set_A(self, A):
        self.color[3] = max(0.0,min(1.0,round(A/255.0,2)))
    A = property(_get_A, _set_A,
                 doc="Alpha channel (0-255)")

    # ___________________________________________________________________ __str__
    def __repr__(self):
        return repr(self.RGBA)


# ------------------------------------------------------------------------------
if __name__ == '__main__':
    c = Color(1)
    c.A = 127
    print c.rgba
    print c.RGBA
