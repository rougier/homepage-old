#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
''' Creates an OpenGL texture from a numpy array Z.

    *Z* may be a float array, a uint8 array or a PIL image. If *Z* is
    an array, *Z* can have the following shapes:
       * MxN   -- L (luminance, float array only)
       * MxNx3 -- RGB (float or uint8 array)
       * MxNx4 -- RGBA (float or uint8 array)
'''
import numpy
from pyglet.gl import *
import colormap

# ------------------------------------------------------------------------------
class Texture(object):
    '''
    Creates an OpenGL texture from a numpy array.

    Example:
    --------
    Z = numpy.ones((256,256))*.5
    texture = Texture(Z)
    glEnable (texture.target)
    glBind (texture.target, texture.id)
    u,v = texture.uv
    glBegin(GL_QUADS)
    glTexCoord2f(0, 0), glVertex2f(x,   y)
    glTexCoord2f(0, u), glVertex2f(x,   y+h)
    glTexCoord2f(v, u), glVertex2f(x+w, y+h)
    glTexCoord2f(v, 0), glVertex2f(x+w, y)
    glEnd()
    '''

    # _________________________________________________________________ __init__
    def __init__(self, Z, cmap=None, interpolation='nearest', origin='lower'):
        ''' Creates an OpenGL texture from Z.

        Parameters:
        -----------
        Z : numpy array
           *Z* may be a float array, a uint8 array or a PIL image. If *Z* is
           an array, *Z* can have the following shapes:
              * MxN   -- L (luminance, float array only)
              * MxNx3 -- RGB (float or uint8 array)
              * MxNx4 -- RGBA (float or uint8 array)

           The value for each component of MxNx3 and MxNx4 float arrays
           should be in the range 0.0 to 1.0; MxN float arrays may be
           normalised.

           cmap: colormap
              Colormap to used for representing single value array

           interpolation: ['nearest' | 'linear']
              Color interpolation algorithm

           origin: ['upper' | 'lower']
              Place the [0,0] index of the array in the upper left or
              lower left corner.
        '''

        self._cmap = cmap
        self._interpolation = interpolation
        self._id = 0
        self._target = GL_TEXTURE_2D
        self._uv = (1,1)
        self._build(Z)

    # _____________________________________________________________ __getitem__
    def __getitem__(self, y):
        ''' x.__getitem__(y) <==> x[y] '''
        return self.Z[y]

    # _____________________________________________________________ __setitem__
    def __setitem__(self, i, y):
        ''' x.__setitem__(i, y) <==> x[i]=y '''
        self.Z[i] = y

    # ___________________________________________________________________ shape
    def _get_shape(self):
        return self.Z.shape
    shape = property (_get_shape, doc='shape of the underlying array.')

    # ___________________________________________________________________ dtype
    def _get_dtype(self):
        return self.Z.dtype
    dtype = property (_get_dtype, doc='dtype of the underlying array.')

    # ____________________________________________________________________ cmap
    def _get_cmap(self):
        return self._cmap
    def _set_cmap(self, cmap):
        if None in [self._cmap, cmap]:
            self._cmap = cmap
            self._build()
        self._cmap = cmap
    cmap = property (_get_cmap, _set_cmap,
                     doc='colormap to be used to render array (of type MxN).')

    # __________________________________________________________________ target
    def _get_target(self):
        return self._target
    target = property (_get_target,
                       doc='GL texture target (e.g., GL_TEXTURE_2D).')

    # ______________________________________________________________________ id
    def _get_id(self):
        if self._id == 0: self.update()
        return self._id
    id = property (_get_id,
                   doc='GL texture name.')

    # ______________________________________________________________________ uv
    def _get_uv(self):
        return self._uv
    uv = property (_get_uv,
                   doc='GL texture U and V coordinates.')

    # ___________________________________________________________ interpolation
    def _get_interpolation(self):
        return self._interpolation
    def _set_interpolation(self, interpolation):
        if self._interpolation != interpolation:
            self._interpolation = interpolation
            self._build()
        self._interpolation = interpolation
    interpolation = property (_get_interpolation, _set_interpolation,
                            doc='GL texture minifying and magnifying function.')

    # ____________________________________________________________________ blit
    def blit(self, x, y, w, h):
        ''' Draw this texture to the active framebuffer. '''

        glEnable (self.target)
        glBindTexture(self.target, self.id)
        u,v = self.uv
        glBegin(GL_QUADS)
        glTexCoord2f(0, 0), glVertex2f(x,   y)
        glTexCoord2f(0, u), glVertex2f(x,   y+h)
        glTexCoord2f(v, u), glVertex2f(x+w, y+h)
        glTexCoord2f(v, 0), glVertex2f(x+w, y)
        glEnd()


    # __________________________________________________________________ _build
    def _build (self, Z):
        ''' Build a new texture from Z shape and type '''

        def get_pow2(num):
            ''' Return the next higher power of two '''
            rval = 1
            while (rval<num):
		rval <<= 1
            return rval

        self.Z = Z
        self.Zn = None
        self.Zi = None
        self.I = None
        dtype = Z.dtype
        shape = Z.shape
        if self._id: glDeleteTextures(self._id)
        if len(shape) == 2:
            if self._cmap == None:
                if dtype != numpy.float32:
                    raise ValueError(
                        'MxN array data type must be float when no colormap.')
                else:
                    self.src_type = GL_FLOAT
                    self.src_format = GL_LUMINANCE
                    self.dst_format = GL_LUMINANCE
            else:
                if dtype not in [numpy.float32, numpy.double]:
                    raise ValueError(
                        'MxN array data type must be float or double.')
                else:
                    self.src_type = GL_UNSIGNED_BYTE
                    self.src_format = GL_RGBA
                    self.dst_format = GL_RGBA
                    self.Zn = Z.copy()
                    self.Zi = self.Zn.astype(numpy.int)
                    self.I = numpy.ndarray((Z.shape[0], Z.shape[1]),
                                           dtype=[('R',numpy.ubyte),
                                                  ('G',numpy.ubyte),
                                                  ('B',numpy.ubyte),
                                                  ('A',numpy.ubyte)])
        elif len(shape) == 3:
            if dtype not in [numpy.float32, numpy.uint8]:
                raise ValueError(
                    'MxNx3 array data type must be float or uint8.')
            elif dtype == numpy.float32:
                self.src_type = GL_FLOAT
                self.src_format = GL_RGB
                self.dst_format = GL_RGB
            elif dtype == numpy.uint8:
                self.src_type = GL_UNSIGNED_BYTE
                self.src_format = GL_RGB
                self.dst_format = GL_RGB
        elif len(shape) == 4:
            if dtype not in [numpy.float32, numpy.uint8]:
                raise ValueError(
                    'MxNx4 array data type must be float or uint8.')
            elif dtype == numpy.float32:
                self.src_type = GL_FLOAT
                self.src_format = GL_RGBA
                self.dst_format = GL_RGBA
            elif dtype == numpy.uint8:
                self.src_type = GL_UNSIGNED_BYTE
                self.src_format = GL_RGBA
                self.dst_format = GL_RGBA
        size = ( max(8, get_pow2(shape[0])),
                 max(8, get_pow2(shape[1])) )
        self._uv = (shape[0]/float(size[0]+0.01),shape[1]/float(size[1]+0.01))
        id = GLuint()
        glGenTextures(1, byref(id))
        self._id = id.value
        glPixelStorei (GL_UNPACK_ALIGNMENT, 1)
        glPixelStorei (GL_PACK_ALIGNMENT, 1)
        glBindTexture (self._target, self._id)
        if self._interpolation == 'linear':
            interpolation = GL_LINEAR
        else:
            interpolation = GL_NEAREST
        glTexParameterf (self._target, GL_TEXTURE_MIN_FILTER, interpolation)
        glTexParameterf (self._target, GL_TEXTURE_MAG_FILTER, interpolation)
        glTexParameterf (self._target, GL_TEXTURE_WRAP_S, GL_CLAMP)
        glTexParameterf (self._target, GL_TEXTURE_WRAP_T, GL_CLAMP)
        glTexImage2D (self._target,  0, self.src_format, size[1], size[0], 0,
                      self.dst_format, self.src_type, 0)
        self.update()

    # ___________________________________________________________________ update
    def update(self):
        ''' Update texture with current array content '''

        glBindTexture(self._target, self._id) 
        if len(self.shape) == 2 and self._cmap is not None:
            glTexSubImage2D (self._target, 0, 0, 0,
                             self.Z.shape[1], self.Z.shape[0],
                             self.src_format, self.src_type,
                             self.__get_RGBA_buffer())
        else:
            glTexSubImage2D (self._target, 0, 0, 0,
                             self.Z.shape[1], self.Z.shape[0],
                             self.src_format, self.src_type,
                             self.Z.ctypes.data)

    # ________________________________________________________ __get_RGBA_buffer
    def __get_RGBA_buffer(self):
        ''' Transform a MxN array into a colored MxNx4 array using a colormap.

        The transformation is done using numpy matrix operations only to try to
        speed things up.
        '''

        LUT = self.cmap.LUT['RGBA']
        cmin, cmax = self.cmap.min, self.cmap.max

        # LUT.size = bad(0) + under(1) + actual # colors + over(size-1)
        self.Zn = numpy.subtract(self.Z, cmin, self.Zn)
        self.Zn *= (LUT.size-3-1)/float(cmax-cmin)

        # Zi holds unranged indices of colors
        # At this stage, they can be negative or superior to LUT.size-3
        self.Zi[...] = self.Zn

        # Set negative indices to become 'under' color (1)
        #  and increment others by 2 to skip bad and under colors
        numpy.maximum (self.Zi+2, 1, self.Zi)

        # Set out-of-range indices to become 'over' color (LUT.size-1)
        numpy.minimum (self.Zi, LUT.size-1, self.Zi)

        # Replace bad indices with 'bad' color indice
        numpy.multiply(self.Zi, 1-numpy.isnan(self.Z), self.Zi)

        LUT.take(self.Zi, mode='clip', out=self.I)
        return self.I.ctypes.data
