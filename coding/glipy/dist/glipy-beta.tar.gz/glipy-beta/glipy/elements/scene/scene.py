#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
import os
from pyglet.gl import *
from trackball import Trackball
from glipy.elements.element import Element

class Scene(Element):
    def __init__(self, width=600, height=400):
        super(Scene,self).__init__(width, height)
        self._focus = False
        self._trackball = Trackball(45,45,1)
        
    def on_mouse_press(self, x, y, button, modifiers):
        if self.hit_test(x,y):
            self._drag_focus = True
            return pyglet.event.EVENT_HANDLED
        self._drag_focus = False
        return pyglet.event.EVENT_UNHANDLED

    def on_mouse_release(self, x, y, button, modifiers):
        if self._drag_focus:
            self._drag_focus = False
            return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    def on_mouse_drag(self, x, y, dx, dy, button, modifiers):
        if self._drag_focus:
            w,h = float(self.width), float(self.height)
            x = (x-self.x)/w -0.5
            y = (y-self.y)/h -0.5
            dx = 2*dx/w
            dy = 2*dy/h
            self._trackball.drag(x,y,dx,dy)
            return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    def on_mouse_scroll(self, x, y, dx, dy):
        if self.hit_test(x,y):
            self._trackball.zoom(x,y,dx,dy)
            return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    def draw(self):
        pass
