#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
''' '''
import pyglet
import codecs
from pyglet.gl import *
from pyglet.window import key
from pyglet.graphics import Batch
from pyglet.text.caret import Caret
from pyglet.text import Label
from pyglet.text.layout import IncrementalTextLayout as Layout
from glipy.editor.document import Document
from glipy.styles import Default

class Editor(object):
    def __init__(self, window, style=Default['editor']):
        '''Create a new editor. '''

        self._style = style
        self._x = 20
        self._y = 20
        self._z = 0
        self._width  = int(style['page_size'][0]*window.width)
        self._height = int(style['page_size'][1]*window.height)
        self._anchor_x = 'left'
        self._anchor_y = 'bottom'
        self._active = False

        batch = Batch()
        document = Document('')
        document.set_style(0,0, {'font_name': style['font_name'],
                                 'font_size': style['font_size'],
                                 'color'    : style['text_fg']})
        width  = self._width
        height = self._height
        layout = Layout(document,
                        width=width, height=height,
                        multiline=True, batch=batch)
        layout.x = window.width-10
        layout.y = window.height-10
        layout.anchor_x = 'left'
        layout.anchor_y = 'bottom'
        layout.selection_color = style['selection_fg']
        layout.selection_background_color = style['selection_bg']
        x = layout.x-style['margin']
        y = layout.y-style['margin']
        z = .1
        w = layout.width+2*style['margin']
        h = layout.height+2*style['margin']
        self.page_bg = batch.add(4, pyglet.gl.GL_QUADS, None,
                            ('v3f', (x,y,z, x+w,y,z, x+w,y+h,z,  x,y+h,z)),
                            ('c4B', style['text_bg']*4))
        z += .1
        self.page_fg = batch.add(4, pyglet.gl.GL_LINE_LOOP, None,
                            ('v3f', (x,y,z, x+w,y,z, x+w,y+h,z,  x,y+h,z)),
                            ('c4B', style['border_fg']*4))
        caret = pyglet.text.caret.Caret(layout)
        caret.visible = True
        caret.color = style['text_fg'][:3]
        cursor = window.get_system_mouse_cursor('text')
        caret.position = len(document.text)
        glEnable(GL_NORMALIZE)
        glEnable(GL_BLEND)

        self._window = window
        self._style = style
        self._document = document
        self._layout = layout
        self._caret = caret
        self._batch = batch
        self._cursor = cursor
        self.resize(width,height)

    # ____________________________________________________________________ open
    def open(self, filename, linenum=0):
        self._active = True
        self._filename = filename
        try:
            file = codecs.open(self._filename, 'r', 'utf-8')
            text = file.read()
        except:
            text = ''
        self._document.begin_not_undoable_action()
        self._document.delete_text(0, len(self._document.text))
        self._document.insert_text(0, text)
        self._document.end_not_undoable_action()

    # ____________________________________________________________________ save
    def save(self, filename):
        self._document.begin_not_undoable_action()
        file = open(filename, 'w')
        file.write(self._document.text)
        file.close()
        self._document.end_not_undoable_action()

    # __________________________________________________________________ active
    def _get_active(self):
        return self._active
    active = property(_get_active,
        doc='''Indicates whether editor is active.

        :type: bool
        ''')
    # _______________________________________________________________________ x
    def _get_x(self):
        return self._x
    def _set_x(self, x):
        self._x = x
        self._update()
    x = property(_get_x, _set_x,
        doc='''Y coordinate of the window editor.

        :type: int
        ''')

    # _______________________________________________________________________ y
    def _get_y(self):
        return self._y
    def _set_y(self, y):
        self._y = y
        self._update()
    y = property(_get_y, _set_y,
        doc='''Y coordinate of the window editor.

        :type: int
        ''')

    # _______________________________________________________________________ z
    def _get_z(self):
        return self._z
    def _set_z(self, z):
        self._z = z
        self._update()
    z = property(_get_z, _set_z,
        doc='''Z coordinate of the editor window.

        :type: int
        ''')
    
    # ___________________________________________________________________ width
    def _get_width(self):
        return self._width
    def _set_width(self, width):
        self._width = width
        self._layout.width = width - 2*self._style['margin']
        self._update()
    width = property(_get_width, _set_width, 
        doc='''Width of the editor window.

        :type: int
        ''')

    # __________________________________________________________________ height
    def _get_height(self):
        return self._height
    def _set_height(self, height):
        self._height = height
        self._layout.height = height - 2*self._style['margin']
        self._update()
    height = property(_get_height, _set_height,
        doc='''Height of the editor window.
        
        :type: int
        ''')


    # _________________________________________________________________ _update
    def _update(self):
        ''' '''

        self._root_y = self._window.height/2 - self.height/2
        self._root_x = self._window.width - self.width - self._root_y
        self._layout.x = self._root_x + self._style['margin']
        self._layout.y = self._root_y + self._style['margin']
        x, y, z = self._root_x+.315, self._root_y+.315, .1
        w, h = self.width, self.height
        self.page_bg.vertices = (x,y,z, x+w,y,z, x+w,y+h,z,  x,y+h,z)
        z += .1
        self.page_fg.vertices = (x,y,z, x+w,y,z, x+w,y+h,z,  x,y+h,z)

    # ________________________________________________________________ hit_test
    def hit_test(self,x,y):
        ''' '''
        return ((self._root_x <= x <= (self._root_x+self._width)) and
                (self._root_y <= y <= (self._root_y+self._height)))

    # __________________________________________________________ on_mouse_press
    def on_mouse_press(self, x, y, button, modifiers):
        if not self._active:
            return pyglet.event.EVENT_UNHANDLED
        if button == pyglet.window.mouse.MIDDLE:
            self._document.paste(self._caret.position, 'PRIMARY')
        elif button == pyglet.window.mouse.LEFT:
            self._caret.on_mouse_press(x, y, button, modifiers)
        return pyglet.event.EVENT_HANDLED

    # ___________________________________________________________ on_mouse_drag
    def on_mouse_drag(self, x, y, dx, dy, button, modifiers):
        if not self._active:
            return pyglet.event.EVENT_UNHANDLED
        self._caret.on_mouse_drag(x, y, dx, dy, button, modifiers)
        return pyglet.event.EVENT_HANDLED

    # _________________________________________________________ on_mouse_release
    def on_mouse_release(self, x, y, button, modifiers):
        if not self._active:
            return pyglet.event.EVENT_UNHANDLED
        if (button == pyglet.window.mouse.LEFT and 
            self._layout.selection_start != self._layout.selection_end):
            self._document.copy(self._layout.selection_start,
                               self._layout.selection_end,
                               'PRIMARY')
    # ________________________________________________________________ on_resize
    def resize(self, width, height):
        self.width = int(width*self._style['page_size'][0])
        self.height = int(height*self._style['page_size'][1])
        self._update()

    # _________________________________________________________________ on_text
    def on_text(self,text):
        ''' '''
        if not self._active:
            return pyglet.event.EVENT_UNHANDLED
        self._caret.on_text(text)
        return pyglet.event.EVENT_HANDLED

    # __________________________________________________________ on_text_motion
    def on_text_motion(self,motion,select=False):
        ''' '''
        if not self._active:
            return pyglet.event.EVENT_UNHANDLED
        self._caret.on_text_motion(motion,select)
        return pyglet.event.EVENT_HANDLED

    # ___________________________________________________ on_text_motion_select
    def on_text_motion_select(self,motion,select=False):
        ''' '''
        if not self._active:
            return pyglet.event.EVENT_UNHANDLED
        self._caret.on_text_motion_select(motion)
        return pyglet.event.EVENT_HANDLED

    # _________________________________________________________ on_mouse_scroll
    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        ''' '''
        if not self._active:
            return pyglet.event.EVENT_UNHANDLED
        self._caret.on_mouse_scroll(x,y,scroll_x, scroll_y)
        return pyglet.event.EVENT_HANDLED
           
    # ____________________________________________________________________ draw
    def draw(self):
        if self._active:
            #glEnable(GL_LINE_SMOOTH)
            glDepthMask(GL_FALSE)
            self._batch.draw()
            glDepthMask(GL_TRUE)
            #glDisable(GL_LINE_SMOOTH)

    # ____________________________________________________________ on_key_press
    def on_key_press(self, symbol, modifiers):
        ''' '''

        if not self._active:
            return pyglet.event.EVENT_UNHANDLED
        # De-activate editor and save file
        elif symbol == key.ESCAPE:
            self._active = False
            self.save(self._filename)
        elif symbol == key.TAB:
            self._document.insert_text(self._caret.position,'    ')
            self._caret.position += 4
        # Start of line
        elif symbol == key.A and modifiers & key.MOD_CTRL:
            p = self._document.text[:self._caret.position].rfind('\n') + 1
            self._caret.position = p
        # End of line
        elif symbol == key.E and modifiers & key.MOD_CTRL:
            p = self._document.text[self._caret.position:].find('\n')
            self._caret.position += p
        # Delete
        elif symbol == key.D and modifiers & key.MOD_CTRL:
            self._document.delete_text(self._caret.position, 
                                       self._caret.position+1)
        # Undo
        elif symbol == key.Z and modifiers & key.MOD_CTRL:
            p = self._document.undo()
            if p:
                self._caret.position = p
        # Redo
        elif symbol == key.Y and modifiers & key.MOD_CTRL:
            p = self._document.redo()
            if p:
                self._caret.position = p
        # Copy
        elif symbol == key.C and modifiers & key.MOD_CTRL:
            self._document.copy(self._layout.selection_start,
                                self._layout.selection_end)
            self._layout.selection_start = self._layout.selection_end
        # Cut
        elif symbol == key.X and modifiers & key.MOD_CTRL:
            p = self._layout.selection_start
            self._document.cut(self._layout.selection_start,
                              self._layout.selection_end)
            self._layout.selection_start = self._layout.selection_end
            self._caret.position = p
        # Paste
        elif symbol == key.V and modifiers & key.MOD_CTRL:
            self._document.paste(self._caret.position)
        else:
            return pyglet.event.EVENT_UNHANDLED
        return pyglet.event.EVENT_HANDLED



# ------------------------------------------------------------------------------
if __name__ == '__main__':
    window = pyglet.window.Window()
    editor = Editor(window=window)
    @window.event
    def on_draw():
        window.clear()
        editor.draw()
    pyglet.app.run()
