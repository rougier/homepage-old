#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------

mono_font = ('Bitstream Vera Sans Mono', 'Courier')

# White style (black on white)
White = {
    'terminal' : {'text_fg'      : (  0,   0,   0, 255),
                  'text_bg'      : (255, 255, 255, 255),
                  'selection_fg' : (  0,   0,   0, 255),
                  'selection_bg' : (  0,   0,   0,  64),
                  'border_fg'    : (255, 255, 255,   0),
                  'margin'       : 6,
                  'font_name'    : mono_font,
                  'font_size'    : 10},
    'editor'   : {'text_fg'      : (  0,   0,   0, 255),
                  'text_bg'      : (245, 245, 255, 225),
                  'selection_fg' : (  0,   0,   0, 255),
                  'selection_bg' : (  0,   0,   0,  64),
                  'border_fg'    : (  0,   0,   0, 255),
                  'margin'       : 6,
                  'font_name'    : mono_font,
                  'font_size'    : 10,
                  'page_size'    : (0.5,0.95)}
    }

# AntiqueWhite style (black on light antique white)
AntiqueWhite = {
    'terminal' : {'text_fg'      : (  0,   0,   0, 255),
                  'text_bg'      : (255, 255, 225, 255),
                  'selection_fg' : (  0,   0,   0, 255),
                  'selection_bg' : (  0,   0,   0,  64),
                  'border_fg'    : (255, 255, 255,   0),
                  'margin'       : 6,
                  'font_name'    : mono_font,
                  'font_size'    : 10},
    'editor'   : {'text_fg'      : (  0,   0,   0, 255),
                  'text_bg'      : (255, 255, 255, 225),
                  'selection_fg' : (  0,   0,   0, 255),
                  'selection_bg' : (  0,   0,   0,  64),
                  'border_fg'    : (  0,   0,   0, 255),
                  'margin'       : 6,
                  'font_name'    : mono_font,
                  'font_size'    : 10,
                  'page_size'    : (0.5,0.95)}
    }

# Black style (white on black)
Black = {
    'terminal' : {'text_fg'      : (255, 255, 255, 255),
                  'text_bg'      : (  0,   0,   0, 255),
                  'selection_fg' : (255, 255, 255, 255),
                  'selection_bg' : (255, 255, 255,  64),
                  'border_fg'    : (255, 255, 255,   0),
                  'margin'       : 6,
                  'font_name'    :  mono_font,
                  'font_size'    : 10},
    'editor'   : {'text_fg'      : (255, 255, 255, 255),
                  'text_bg'      : (  0,   0,   0, 225),
                  'selection_fg' : (255, 255, 255, 255),
                  'selection_bg' : (255, 255, 255,  64),
                  'border_fg'    : (255, 255, 255, 255),
                  'margin'       : 6,
                  'font_name'    :  mono_font,
                  'font_size'    : 10,
                  'page_size'    : (0.5,0.95)}
    }
Default = AntiqueWhite
