#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
'''
The terminal package is the main component of glipy and provides support for a
graphic interactive terminal based on pyglet.
'''
import sys, os, re
import tempfile
import readline
from StringIO import StringIO
import glipy
import pyglet
from pyglet.text.formats.structured import ImageElement
from pyglet.window import key
from console import Console
import time
import shell


# ------------------------------------------------------------ class TerminalOut
class TerminalOut:
    """
    A fake output file object.  It sends output to the terminal widget,
    and if asked for a file number, returns one set on instance creation
    """
    
    def __init__(self, terminal, app, fn=-1):
        self.fn = fn
        self.terminal = terminal
    def close(self): pass
    flush = close
    def fileno(self):    return self.fn
    def isatty(self):    return True
    def read(self, a):   return ''
    def readline(self):  return ''
    def readlines(self): return []
    def write(self, s):
        self.terminal.write (s)
    def writelines(self, l):
        for s in l:
            self.terminal.write (s)
    def seek(self, a):   raise IOError, (29, 'Illegal seek')
    def tell(self):      raise IOError, (29, 'Illegal seek')
    truncate = tell


# ------------------------------------------------------------- class TerminalIn
class TerminalIn:
    """
    A fake input file object.  It receives input from a GTK TextView widget,
    and if asked for a file number, returns one set on instance creation
    """
    def __init__(self, terminal, fn=-1):
        self.fn = fn
        self.terminal = terminal
    def close(self): pass
    flush = close
    def fileno(self):    return self.fn
    def isatty(self):    return True
    def read(self, a):   return self.readline()
    def readline(self):
        self.terminal.interrupt = False
        self.terminal.input_mode = True
        self.terminal.prompt('')
        while self.terminal.input_mode:
            time.sleep(1.0/60.0)
            pyglet.clock.tick()
            for window in pyglet.app.windows:
                window.switch_to()
                window.dispatch_events()
                window.dispatch_event('on_draw')
                window.flip()
        if self.terminal.interrupt:
            raise KeyboardInterrupt
        s = self.terminal.command
        return str(s)
    def readlines(self): return []
    def write(self, s):  return None
    def writelines(self, l): return None
    def seek(self, a):   raise IOError, (29, 'Illegal seek')
    def tell(self):      raise IOError, (29, 'Illegal seek')
    truncate = tell


# --------------------------------------------------------------- class Terminal
class Terminal(Console):
    ''' '''
    
    # _________________________________________________________________ __init__
    def __init__(self, window,
                 ns_locals={}, ns_globals={}, argv=None, 
                 shellname='python', logo=None, banner=None,
                 history_file=None, history_size=100, *args, **kwargs):
        ''' '''
        super(Terminal, self).__init__(window=window, *args, **kwargs)
        self.interrupt = False
        self.input_mode = False
        self.stdout = TerminalOut (self, sys.stdout.fileno())
        self.stderr = TerminalOut (self, sys.stderr.fileno())
        self.stdin  = TerminalIn  (self, sys.stdin.fileno())
        self.fifoname = tempfile.mktemp()
        if not os.path.exists (self.fifoname):
            os.mkfifo (self.fifoname)
        self.piperead = os.open (self.fifoname, os.O_RDONLY | os.O_NONBLOCK)
        self.pipewrite = os.open (self.fifoname, os.O_WRONLY | os.O_NONBLOCK)
        self.logo = None
        if logo:
            self.logo = logo
            self.logo.anchor_x = self.logo.width
            self.logo.anchor_y = 0

        # Python stdout, stderr, stdin redirection
        if 1:
            self.__sys_stdout__ = sys.stdout
            self.__sys_stderr__ = sys.stderr
            self.__sys_stdin__  = sys.stdin
            sys.stdout = self.stdout
            sys.stderr = self.stderr
            sys.stdin  = self.stdin
            # System stdout, stderr redirection
            self.__stdout = os.dup(1)
            self.__stderr = os.dup(2)
            os.dup2 (self.pipewrite, 1)
            os.dup2 (self.pipewrite, 2)

        self.argv = argv
        if shellname == 'python':
            self.shell = shell.Shell(ns_locals,ns_globals)
            if not banner:
                banner  = 'GLiPy %s -- The OpenGL IPython/Python terminal.\n' % glipy.__version__
                banner += 'Python %s on %s\n"' % (sys.version, sys.platform)
                banner += 'Type "help", "copyright", "credits" '
                banner += 'or "license" for more information.\n'
        else:
            # If we import IPython before stdin/stdout/stderr redirection
            # then the terminal fails at catching help() output for example.
            # Don't know why yet.
            try:
                import ishell
            except:
                pass
            self.cout = StringIO()
            self.cout.truncate(0)
            self.shell = ishell.Shell(argv,ns_locals,ns_globals,
                                      cout=self.cout, cerr=self.cout,
                                      input_func=self.raw_input)
            history_file = self.shell.IP.histfile
            if not banner:
                banner = 'GLiPy %s -- The OpenGL IPython/Python terminal.\n' % glipy.__version__
                banner += self.shell.IP.BANNER

        self.history_init (history_file, history_size)

        if banner:
            self.write(banner)
        self._prompt = self.shell.prompt
        self.prompt()

    # ____________________________________________________________ history_init
    def history_init(self, filename, size):
        ''' '''
        self.history_file = filename
        self.history_size = size
        if filename and os.path.exists(filename):
            readline.read_history_file(filename)
        self.history_reset()

    # ____________________________________________________________ history_save
    def history_save(self):
        ''' '''
        if self.history_file:
            readline.write_history_file(self.history_file)

    # _____________________________________________________________ history_add
    def history_add(self, item):
        ''' '''
        if len(item):
            readline.add_history (item)
        self.history_reset()

    # ___________________________________________________________ history_reset
    def history_reset(self):
        ''' '''
        self.history_index = readline.get_current_history_length()+1

    # ________________________________________________________________ on_close
    def on_close(self):
        ''' '''

        # Get system output and remove system redirection
        os.dup2 (self.__stdout, 1)
        os.dup2 (self.__stderr, 2)
        os.close (self.__stdout)
        os.close (self.__stderr)
        # Remove python redirection
        sys.stdout = self.__sys_stdout__
        sys.stderr = self.__sys_stderr__
        sys.stdint = self.__sys_stdin__
        pyglet.app.exit()
        self.history_save()

    # ____________________________________________________________ history_next
    def on_history_next(self, command):
        ''' '''
        self.history_index += 1
        h = ''
        if self.history_index <= readline.get_current_history_length():
            h = '' or readline.get_history_item (self.history_index)
        else:
            self.history_index = readline.get_current_history_length()+1
        self.command = h

    # ____________________________________________________________ history_prev
    def on_history_prev(self, command):
        ''' '''
        if self.history_index > 1:
            self.history_index -= 1
        else:
            self.history_index = 1
        h = '' or readline.get_history_item (self.history_index)
        self.command = h

    # ___________________________________________________________ on_completion
    def on_completion(self, command):
        ''' '''
        if not command.strip():
            return 
        completed, possibilities = self.shell.complete(command)
        n = len(possibilities)
        if n >= 256:
            a = raw_input('\nDisplay all %d possibilities? (y or n) ' % n)
            if a != 'y':
                slice = command
                self.prompt(self.shell.prompt)
                self.command = completed or slice
                return
        if (n > 1):
            slice = command
            self.write('\n')
            for symbol in possibilities:
                self.write(symbol+'\n')
            self.prompt()
        self.command = completed or slice

    # _______________________________________________________________ raw_input
    def raw_input(self, prompt=''):
        ''' '''
        #if self.interrupt:
        #    self.interrupt = False
        #    raise KeyboardInterrupt
        return self.command

    # ________________________________________________________________ on_text
    def on_text(self, text):
        if self._caret.position < self._prompt_end:
            self._caret.position = len(self._document.text)
        if text == '\r':
            self.dispatch_event('on_command', self.command)
        else:
            self._caret.on_text(text)

    # ________________________________________________________________ on_exit
    def on_exit (self):
        ''' '''
        pyglet.app.exit()
        self.history_save()

    # ______________________________________________________________ on_command
    def on_command (self, command):
        ''' '''
        if self.input_mode:
            self.input_mode = False
            self.write('\n')
            return
        self.shell.eval(self, command)
        self.history_add(command)
        self._prompt = self.shell.prompt

    # _______________________________________________________________ raw_input
    def on_interrupt(self):
        ''' '''
        if not self.input_mode:
            self.write('\nKeyboard Interrupt\n')
        self.interrupt = True
        self.input_mode = False
        self.prompt()

    # ____________________________________________________________________ draw
    def draw(self):
        ''' Draws console. '''
        super(Terminal,self).draw()
        if self.logo:
            #margin = self._style['margin']
            #self.logo.blit(self._width - margin, margin, .5)
            margin = 0
            self.logo.blit(self._width - margin, margin, .5)


# -----------------------------------------------------------------------------
if __name__ == '__main__':
    import os, sys
    from pyglet.gl import *
    from optparse import OptionParser
    import IPython
    width = 600
    height = 400
    filename = os.path.expanduser("~/.pyhistory")
    shellname = 'python'
    window = pyglet.window.Window(width, height, resizable=True)
    terminal = Terminal(window=window,
                        width=width, height=height,
                        ns_locals=locals(), ns_globals=globals(),
                        history_file=filename, history_size=100)

    @window.event
    def on_resize(width, height):
        terminal.resize(width,height)

    @window.event
    def on_draw():
        window.clear()
        terminal.draw()

    window.push_handlers(terminal)
    pyglet.app.run()
