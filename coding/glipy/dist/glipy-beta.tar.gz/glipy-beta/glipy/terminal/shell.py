#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
import os, sys
import re
import rlcompleter
import traceback
import tempfile
import pyglet

if not hasattr(sys, 'ps1'): sys.ps1 = '>>> '
if not hasattr(sys, 'ps2'): sys.ps2 = '... '

# ------------------------------------------------------------------ class Shell
class Shell:
    """ """

    # _________________________________________________________________ __init__
    def __init__(self, ns_globals={}, ns_locals={}):
        """ """

        self.completer = rlcompleter.Completer (ns_globals)
        self.command = ''
        self.globals = ns_globals
        self.locals = ns_locals
        self.complete_sep = re.compile('[\s\{\}\[\]\(\)]')
        self.prompt = sys.ps1

    # _____________________________________________________________ is_balanced
    def is_balanced (self, line):
        """ Checks line balance for brace, bracket, parenthese and string quote

        This helper function checks for the balance of brace, bracket,
        parenthese and string quote. Any unbalanced line means to wait until
        some other lines are fed to the terminal.
        """
        
        s = line
        s = filter(lambda x: x in '()[]{}"\'', s)
        s = s.replace ("'''", "'")
        s = s.replace ('"""', '"')
        instring = False
        brackets = {'(':')', '[':']', '{':'}', '"':'"', '\'':'\''}
        stack = []
        while len(s):
            if not instring:
                if s[0] in ')]}':
                    if stack and brackets[stack[-1]] == s[0]:
                        del stack[-1]
                    else:
                        return False
                elif s[0] in '"\'':
                    if stack and brackets[stack[-1]] == s[0]:
                        del stack[-1]
                        instring = False
                    else:
                        stack.append(s[0])
                        instring = True
                else:
                    stack.append(s[0])
            else:
                if s[0] in '"\'' and stack and brackets[stack[-1]] == s[0]:
                    del stack[-1]
                    instring = False
            s = s[1:]
        return len(stack) == 0
        
    # ________________________________________________________________ complete
    def complete(self, line):
        
        split_line = self.complete_sep.split(line)
        possibilities = []
        i = 0
        try:
            c = self.completer.complete (split_line[-1], i)
        except:
            return line, []
        while c:
            possibilities.append(c)
            i = i+1
            c = self.completer.complete (split_line[-1], i)
        if possibilities:
            common_prefix = os.path.commonprefix (possibilities)
            completed = line[:-len(split_line[-1])]+common_prefix
        else:
            completed = line
        return completed, possibilities

    # ____________________________________________________________________ eval
    def eval (self, terminal, command):
        ''' '''

        terminal.write ('\n')
        if command == '':
            self.execute (terminal)
            self.command = ''
            self.prompt = sys.ps1
            terminal.prompt(sys.ps1)
            return
        self.command = self.command + command + '\n'
        if not self.is_balanced (self.command):
            self.prompt = sys.ps2
            terminal.prompt(sys.ps2)
            return
        command = command.rstrip()
        if len(command) > 0:
            if command[-1] == ':' or command[-1] == '\\' or command[0] in ' \11':
                self.prompt = sys.ps2
                terminal.prompt(sys.ps2)
                return
        self.execute (terminal)
        self.command = ''
        self.prompt = sys.ps1
        terminal.prompt(sys.ps1)

    # _________________________________________________________________ execute
    def execute (self, terminal):
        ''' '''

        if not self.command:
            return
        try:
            try:
                r = eval (self.command, self.globals, self.locals)
                if r is not None:
                    # System output (if any)
                    while True:
                        try:
                            buf = os.read(terminal.piperead, 256)
                        except:
                            break
                        else:
                            terminal.write (buf, 'output')
                            if len(buf) < 256: break
                    # Command output
                    print `r`
            except SyntaxError:
                exec self.command in self.globals
        except:
            if hasattr (sys, 'last_type') and sys.last_type == SystemExit:
                terminal.on_exit()
            elif hasattr (sys, 'exc_type') and sys.exc_type == SystemExit:
                terminal.on_exit()
            else:
                try:
                    tb = sys.exc_traceback
                    if tb:
                        tb=tb.tb_next
                    traceback.print_exception (sys.exc_type, sys.exc_value, tb)
                except:
                    sys.stderr = terminal.__sys_stderr__
                    traceback.print_exc()
                    sys.stderr = terminal.stderr
