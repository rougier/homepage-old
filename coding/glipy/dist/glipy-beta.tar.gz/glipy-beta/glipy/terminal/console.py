#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
''' A pyglet interactive console.

Example usage:
--------------
    window = pyglet.window.Window()
    console = Console()

    @window.event
    def on_draw():
        window.clear()
        console.draw()

    @console.event
    def on_command(command):
        print command

    console.prompt("> ")
    window.push_handlers(console)
    pyglet.app.run()
'''
import pyglet
from pyglet.window import key
from pyglet.text.caret import Caret
from pyglet.event import EventDispatcher
from pyglet.text.document import FormattedDocument as Document
from pyglet.text.layout import IncrementalTextLayout as Layout
from glipy.styles import Default
from glipy import clipboard


# --------------------------------------------------------------- class Console
class Console(EventDispatcher):
    ''' Interactive console. '''
    
    # ________________________________________________________________ __init__
    def __init__(self, window,
                 x=0, y=0, width=100, height=100,
                 anchor_x='left', anchor_y='bottom',
                 style = Default['terminal'], prompt = '> ', banner = ''):
        '''Create a new console.

        :Parameters:
            `window` : pyglet.window.Window
                Window this console will be embedded in.
            `x` : int
                X coordinate of the console.
            `y` : int
                Y coordinate of the console.
            `width` : int
                Width of the console in pixels, or None
            `height` : int
                Height of the console in pixels, or None
            `anchor_x` : str
                Anchor point of the X coordinate: one of ``"left"``,
                ``"center"`` or ``"right"``.
            `anchor_y` : str
                Anchor point of the Y coordinate: one of ``"bottom"``,
                ``"center"`` or ``"top"``.
            `style` : dict
                Style dictionnary describing element styles
            `prompt` : str
                Console prompt
            `banner` : str
                Text to be displayed prior to any input.
        '''

        super(Console, self).__init__()
        self._window = window
        self._style = style
        self._prompt = prompt
        self._prompt_start, self._prompt_end = 0, 0
        batch = pyglet.graphics.Batch()
        document = Document()
        margin = self._style['margin']
        layout = Layout(document,
                        width=width-2*margin, height=height-2*margin,
                        multiline=True, batch=batch)
        layout.anchor_x = anchor_x
        layout.anchor_y = anchor_y
        layout.x = int(margin)
        layout.y = int(margin)
        layout.view_y = 0
        layout.selection_color = self._style['selection_fg']
        layout.selection_background_color = self._style['selection_bg']
        caret = Caret(layout)
        caret.position = 0
        caret.visible = True
        r,g,b,a = self._style['text_fg']
        caret.color = (r,g,b)
        self._batch = batch
        self._document = document
        self._layout = layout
        self._caret = caret
        x,y,z = int(layout.x-margin), int(layout.y-margin), -.5
        w,h = layout.width+2*margin, layout.height+2*margin
        self._background = batch.add(
            4, pyglet.gl.GL_QUADS, None,
            ('v3f', (x,y,z, x+w,y,z, x+w,y+h,z,  x,y+h,z)),
            ('c4B', self._style['text_bg']*4))
        z += .1
        self._border = batch.add(
            4, pyglet.gl.GL_LINE_LOOP, None,
            ('v3f', (x,y,z, x+w,y,z, x+w,y+h,z,  x,y+h,z)),
            ('c4B', self._style['border_fg']*4))
        if banner:
            self.write(banner)
        if window:
            self._cursor = window.get_system_mouse_cursor('text')
        else:
            self._cursor = None
        self.resize(width,height)

    # _________________________________________________________________ command
    def _get_command(self):
        return self._document.text[self._prompt_end:]
    def _set_command(self, text, attributes=None):
        self._document.delete_text(self._prompt_end, len(self._document.text))
        self.write(text, attributes)
        self._caret.position = len(self._document.text)
    command = property(_get_command, _set_command,
                         doc='''Current command line.

    :type: str
    ''')

    # ___________________________________________________________________ write
    def write(self, text, attributes=None):
        ''' Writes text on console. '''

        apply_style = len(self._document.text) == 0
        self._layout.begin_update()
        self._document.insert_text (len(self._document.text), text, attributes)
        if apply_style:
            self._document.set_style(0,len(self._document.text),
                       {'color'     : self._style['text_fg'],
                        'font_name' : self._style['font_name'],
                        'font_size' : self._style['font_size']})
        self._layout.end_update()

    # __________________________________________________________________ insert
    def insert(self, element):
        ''' Insert element into console. '''
        self._layout.begin_update()
        self._document.insert_element(len(self._document.text), element)
        self._layout.end_update()
        self.write('\n')

    # __________________________________________________________________ prompt
    def prompt(self, text=None, attributes=None):
        ''' Prompt for a new command. '''
        if text is not None:
            self._prompt = text
        self._prompt_start = len(self._document.text)
        self.write(self._prompt, attributes)
        self._prompt_end = len(self._document.text)
        self._caret.position = len(self._document.text)

    # __________________________________________________________________ resize
    def resize(self, width, height):
        ''' Adapts console to new size. '''

        self._width = width
        self._height = height
        layout = self._layout
        background = self._background
        border = self._border
        margin = self._style['margin']
        layout.x = margin
        layout.y = margin
        layout.height = height-2*margin
        layout.width  = width-2*margin
        layout.view_y = -layout.content_height
        x,y,z = layout.x-margin-1, layout.y-margin-1, -.5
        w,h = layout.width+2*margin+2, layout.height+2*margin+2
        background.vertices = (x,y,z, x+w,y,z, x+w,y+h,z,  x,y+h,z)
        z += .1
        border.vertices = (x,y,z, x+w,y,z, x+w,y+h,z,  x,y+h,z)

    # ____________________________________________________________________ draw
    def draw(self):
        ''' Draws console. '''
        self._batch.draw()
        for element in self._document._elements:
            if hasattr(element, 'draw'):
                element.draw()

    # __________________________________________________ move_character_forward
    def move_character_forward(self, select=False):
        self._caret.on_text_motion(key.MOTION_RIGHT,select)

    # _________________________________________________ move_character_backward
    def move_character_backward(self, select=False):
        if  self._caret.position > self._prompt_end:
            self._caret.on_text_motion(key.MOTION_LEFT,select)

    # ________________________________________________ delete_character_forward
    def delete_character_forward(self, select=False):
        self._caret.on_text_motion(key.MOTION_DELETE, select)

    # _______________________________________________ delete_character_backward
    def delete_character_backward(self, select=False):
        if  self._caret.position > self._prompt_end:
            self._caret.on_text_motion(key.MOTION_BACKSPACE, select)

    # _________________________________________________________ move_line_start
    def move_line_start(self, select=False):
        self._caret.position = self._prompt_end

    # ___________________________________________________________ move_line_end
    def move_line_end(self, select=False):
        self._caret.position = len(self._document.text)

    # ____________________________________________________________________ kill
    def kill(self):
        self.cut(self._caret.position, len(self._document.text))

    # ____________________________________________________________________ yank
    def yank(self):
        self.paste(self._caret.position)

    # ____________________________________________________________________ copy
    def copy(self, start, end, name = 'CLIPBOARD'):
        ''' '''
        if name == 'PRIMARY':
            self.killbuffer = self._document.text[start:end]
        else:
            self.clipboard = self._document.text[start:end]

    # _____________________________________________________________________ cut
    def cut(self, start, end, name = 'CLIPBOARD'):
        ''' '''
        if name == 'PRIMARY':
            self.killbuffer = self._document.text[start:end]
        else:
            self.clipboard = self._document.text[start:end]
        self._document.delete_text(start,end)

    # ___________________________________________________________________ paste
    def paste(self, start, name = 'CLIPBOARD'):
        ''' '''
        if name == 'PRIMARY':
            clipboard = self.killbuffer
        else:
            clipboard= self.clipboard
        if clipboard:
            self._document.insert_text(start, clipboard)

    # ___________________________________________________________________ clear
    def clear(self):
        ''' Clears console text buffer. '''
        self._document.delete_text(0, self._prompt_start)
        self._prompt_end   -= self._prompt_start
        self._prompt_start -= self._prompt_start

    # _________________________________________________________ on_mouse_motion
    def on_mouse_motion(self, x, y, dx, dy):
        ''' Takes care of text cursor. '''
        self._window.set_mouse_cursor(self._cursor)
        return pyglet.event.EVENT_HANDLED

    # _________________________________________________________ on_mouse_scroll
    def on_mouse_scroll(self, x, y, dx, dy):
        ''' Scroll layout according to mouse scroll. '''
        self._caret.on_mouse_scroll(x, y, dx,dy)
        return pyglet.event.EVENT_HANDLED

    # __________________________________________________________ on_mouse_press
    def on_mouse_press(self, x, y, button, modifiers):
        if button == pyglet.window.mouse.MIDDLE:
            if self._caret.position <= self._prompt_end:
                self.paste(self._prompt_end, 'PRIMARY')
            else:
                self.paste(self._caret.position, 'PRIMARY')
            return pyglet.event.EVENT_HANDLED
        elif button == pyglet.window.mouse.LEFT:
            self._caret.on_mouse_press(x, y, button, modifiers)
            return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    # ___________________________________________________________ on_mouse_drag
    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        ''' Selects text. '''
        self._caret.on_mouse_drag(x, y, dx, dy, buttons, modifiers)

    # ________________________________________________________ on_mouse_release
    def on_mouse_release(self, x, y, button, modifiers):
        if (button == pyglet.window.mouse.LEFT and 
            self._layout.selection_start != self._layout.selection_end):
            self.copy(self._layout.selection_start,
                      self._layout.selection_end,
                      'PRIMARY')
            return pyglet.event.EVENT_HANDLED
        return pyglet.event.EVENT_UNHANDLED

    # _________________________________________________________________ on_text
    def on_text(self, text):
        ''' Handles text. '''
        if self._caret.position <= self._prompt_end:
            self._caret.position = len(self._document.text)
        if text == '\r':
            self.dispatch_event('on_command', self.command)
            self.write ('\n')
            self.prompt()
        else:
            self._caret.on_text(text)

    # __________________________________________________________ on_text_motion
    def on_text_motion(self, motion, select=False):
        ''' Handles text motion. '''
        if motion == key.MOTION_LEFT:
            self.move_character_backward(select)
        elif motion == key.MOTION_RIGHT:
            self.move_character_forward(select)
        elif motion == key.MOTION_UP:
            self.dispatch_event('on_history_prev', self.command)
        elif motion == key.MOTION_DOWN:
            self.dispatch_event('on_history_next', self.command)
        elif motion == key.MOTION_DELETE:
            self.delete_character_forward(select)
        elif motion == key.BACKSPACE:
            self.delete_character_backward(select)
        elif motion == key.MOTION_BEGINNING_OF_LINE:
            self.move_line_start(select)
        elif motion == key.MOTION_END_OF_LINE:
            self.move_line_end(select)

    # ____________________________________________ on_text_select_motion_select
    def on_text_motion_select(self, motion):
        ''' Handles text selection. '''
        if self._caret.mark is None:
            self._caret.mark = self._caret.position
        #return self._caret.on_text_motion_select (motion)
        return self.on_text_motion(motion, True)

    # ____________________________________________________________ on_key_press
    def on_key_press(self, symbol, modifiers):
        ''' Handles key press. '''

        if key.MOD_CTRL & modifiers:
            if symbol == key.A:
                self.move_line_start(self)
            elif symbol == key.B:
                self.move_character_backward(self)
            elif symbol == key.C:
                self.dispatch_event('on_interrupt')
            elif symbol == key.D:
                if not self.command:
                    self.dispatch_event('on_exit')
                else:
                    self.delete_character_forward()
            elif symbol == key.E:
                self.move_line_end(self)
            elif symbol == key.F:
                self.move_character_forward(self)
            elif symbol == key.K:
                self.kill()
            elif symbol == key.L:
                self.clear()
            elif symbol == key.Y:
                self.yank()
            else:
                return pyglet.event.EVENT_UNHANDLED
        else:
            if symbol == key.TAB:
                self.dispatch_event('on_completion',self.command)
            if symbol == key.ESCAPE:
                pass
            else:
                return pyglet.event.EVENT_UNHANDLED
        return pyglet.event.EVENT_HANDLED

    # _______________________________________________________________ clipboard
    def _get_clipboard(self):
        self._clipboard = clipboard.get_text() or self._clipboard
        return self._clipboard
    def _set_clipboard(self, text):
        self._clipboard = text
        clipboard.set_text(text)
    clipboard = property(_get_clipboard, _set_clipboard)

    # ______________________________________________________________ killbuffer
    def _get_killbuffer(self):
        self._killbuffer = clipboard.get_text('PRIMARY') or self._killbuffer
        return self._killbuffer
    def _set_killbuffer(self, text):
        self._killbuffer = text
        clipboard.set_text(text, 'PRIMARY')
    killbuffer = property(_get_killbuffer, _set_killbuffer)


Console.register_event_type('on_command')
Console.register_event_type('on_exit')
Console.register_event_type('on_interrupt')
Console.register_event_type('on_completion')
Console.register_event_type('on_history_next')
Console.register_event_type('on_history_prev')


# -----------------------------------------------------------------------------
if __name__ == '__main__':
    from pyglet.gl import *

    window = pyglet.window.Window(width=600, height=400, resizable=True)
    console = Console(width=600, height=400, window=window)

    @window.event
    def on_draw():
        glClearColor(1,1,1,1)
        window.clear()
        console.draw()

    @window.event
    def on_resize(width, height):
        console.resize(width,height)

    @console.event
    def on_command(command):
        print command

    console.prompt("> ")
    window.push_handlers(console)
    pyglet.app.run()
