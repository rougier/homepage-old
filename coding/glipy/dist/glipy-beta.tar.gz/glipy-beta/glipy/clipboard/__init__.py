#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
'''Interaction with the Operating System text clipboard'''
import sys

def get_text(name = 'CLIPBOARD'):
    '''Get a string from the clipboard.
    '''
    return _clipboard.get_text(name)

def set_text(text, name = 'CLIPBOARD'):
    '''Put the string onto the clipboard.
    '''
    return _clipboard.set_text(text, name)

# Try to determine which platform to use.
if sys.platform == 'darwin':
    from carbon import CarbonPasteboard
    _clipboard = CarbonPasteboard()
elif sys.platform in ('win32', 'cygwin'):
    from win32 import Win32Clipboard
    _clipboard = Win32Clipboard()
else:
    from xlib import XlibClipboard
    _clipboard = XlibClipboard()

