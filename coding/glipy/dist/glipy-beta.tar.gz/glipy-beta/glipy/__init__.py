#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
'''
One  of Python's  most useful  features is  its interactive  interpreter.  This
system allows very fast testing of  ideas without the overhead of creating test
files as is typical in  most programming languages. Furthermore, NumPy provides
a fundamental package needed for  scientific computing with Python and contains
a powerful N-dimensional array object as  well as a lot of useful functions and
tools. However, the interpreter  supplied with the standard Python distribution
is somewhat limited for extended interactive use since it does not provide fast
visualization capabilities.  One can  use additonal packages such as matplotlib
or  mayavi   mlab  package,  but   those  are  more  oriented   towards  static
visualization.

The goal of GLiPy is to  create a comprehensive environment for interactive and
exploratory computing. To support this goal, GLiPy has two main components:

* An interactive Python terminal.
* An architecture for embedding various elements directly within the terminal.

All of GLiPy is open source (released under the revised BSD license).
'''

__version__ = 'beta'
