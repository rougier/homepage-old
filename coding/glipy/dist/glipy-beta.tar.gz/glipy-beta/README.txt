============
GLiPy README
============

Overview
========

Welcome to GLiPy.  Our documentation can be found in  the docs subdirectory. We
also have  ``.html`` and ``.pdf``  versions of this documentation  available on
the glipy `website <http://www.loria.fr/~rougier/glipy>`_.

Requirements
============

 * Python >= 2.4
 * Pyglet >= 1.1.2
 * IPython >= 0.8
