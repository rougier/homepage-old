#! /usr/bin/env python
# -*- coding: utf-8 -*-
# -----------------------------------------------------------------------------
# GLiPy -- An OpenGL Python terminal
# Copyright (c) 2009 Nicolas Rougier <Nicolas.Rougier@loria.fr>
#
# Distributed under  the terms of the BSD  License. The full license  is in the
# file file COPYING, distributed as part of this software.
# -----------------------------------------------------------------------------
import os
from ez_setup import use_setuptools
use_setuptools()
from setuptools import setup

# BEFORE importing distutils, remove MANIFEST. distutils doesn't properly
# update it when the contents of directories change.
if os.path.exists('MANIFEST'):
    os.remove('MANIFEST')

setup(name="glipy",
      version='beta',
      url='https://launchpad.net/glipy',
      license='BSD',
      author='Nicolas Rougier',
      author_email='Nicolas.Rougier@loria.fr',
      description='OpenGL Python terminal',
      platforms='any',
      packages=['glipy',
                'glipy.terminal',
                'glipy.elements',
                'glipy.elements.numpy',
                'glipy.elements.scene',
                'glipy.styles',
                'glipy.editor',
                'glipy.clipboard'],
      package_data={'glipy': ['data/logo.png']},
      scripts=['scripts/glipy'],
      install_requires = {
        'pyglet':  ["pyglet>=1.1.2"]
        },
      extras_require = {
        'IPython':  ["IPython>=0.8"],
        'numpy':    ["numpy>=1.2"],
        }

)
